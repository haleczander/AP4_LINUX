# AP4 Projet Linux - Mon Super Archiver

- Alexandre HERSSENS
- Arthur FOULON
- Etan DUCOURTY

## Cette archive comprend :
- Un dossier d'[`installation`](./install_dir/README.md) avec explication du programme
- Un dossier avec une [`démonstration du programme`](./demonstration/README.md) 